Open this folder in Android Studio (Arctic Fox or newer). Android Studio will generate Gradle wrapper files automatically.

Then Build -> Build Bundle(s) / APK(s) -> Build APK(s).